`timescale 1ns/1ns

module test ;
   reg  ai, bi ;

   initial begin
      ai        = 0 ;
      #25 ;      ai        = 1 ;
      #35 ;      ai        = 0 ;        //absolute 60ns
      #40 ;      ai        = 1 ;        //absolute 100ns
      #10 ;      ai        = 0 ;        //absolute 110ns
   end

   initial begin
      bi        = 1 ;
      #70 ;      bi        = 0 ;        //absolute 70ns
      #20 ;      bi        = 1 ;        //absolute 90ns
   end

   /*
   initial begin
      forever begin
         #100;
         //$display("---gyc---%d", $time);
         if ($time >= 1000) begin
            $finish ;
         end
      end
   end
   */

   parameter CLK_FREQ   = 100 ; //100MHz
   parameter CLK_CYCLE  = 1e9 / (CLK_FREQ * 1e6) ;   //switch to ns

   reg  clk ;
   initial clk = 1'b0 ;      //clk is initialized to "0"
   always # (CLK_CYCLE/2) clk = ~clk ;       //always reversing, and generating a real clock

   always begin
      #10;
      if ($time >= 110) begin
         $finish ;
      end
   end


endmodule
