`timescale 1ns/1ns

module test ;
   reg          rstn ;
   reg          clk ;
   reg [3:0]    cnt ;
   wire         cout ;

   counter10     u_counter (
       .rstn    (rstn),
       .clk     (clk),
       .cnt     (cnt),
       .cout    (cout));

   initial begin
      clk       = 0 ;
      rstn      = 0 ;
      #10 ;
      rstn      = 1'b1 ;
      wait (test.u_counter.cnt_temp == 4'd4) ;
      @(negedge clk) ;
      force     test.u_counter.cnt_temp = 4'd6 ;
      force     test.u_counter.cout     = 1'b1 ;
      #40 ;
      @(negedge clk) ;
      release   test.u_counter.cnt_temp ;
      release   test.u_counter.cout ;
   end

   initial begin
      clk = 0 ;
      forever #10 clk = ~ clk ;
   end

   //finish the simulation
   always begin
         #1000;
         if ($time >= 1000) $finish ;
   end


endmodule // test
