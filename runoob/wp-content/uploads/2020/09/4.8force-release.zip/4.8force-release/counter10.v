module counter10(

                 input                   rstn,
                 input                   clk,
                 output [3:0]            cnt,
                 output                  cout);

   reg [3:0]                             cnt_temp ;
   always@(posedge clk or negedge rstn) begin
      if(! rstn)begin
         cnt_temp        <= 4'b0 ;
      end
      else if (cnt_temp==4'd9) begin
         cnt_temp        <=4'b000;
      end
      else begin
         cnt_temp        <= cnt_temp + 1'b1 ;
      end
   end


   assign  cout = (cnt_temp==4'd9) ;
   assign  cnt  = cnt_temp ;

endmodule // counter10



module dff_normal(
    input       rstn,
    input       clk,
    input       D,
    output reg  Q
 );

   always @(posedge clk or negedge rstn) begin
      if(!rstn) begin   //Q = 0 after reset effective
         Q <= 1'b0 ;
      end
      else begin
         Q <= D ;       //Q = D at posedge of clock
      end
   end

endmodule // dff_normal


module dff_assign(
    input       rstn,
    input       clk,
    input       D,
    output reg  Q
 );

   always @(posedge clk) begin
         Q <= D ;       //Q = D at posedge of clock
   end

   always @(negedge rstn) begin
      if(!rstn) begin
         assign Q = 1'b0 ;      //change the Q value when reset effective
      end
      else begin        //cancel the Q value overlay,
         deassign Q ;   //and Q remains 0-value until the coming of clock posedge
      end
   end

endmodule // dff_normal
