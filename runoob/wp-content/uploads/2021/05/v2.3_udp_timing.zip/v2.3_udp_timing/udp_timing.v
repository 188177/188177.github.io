primitive D_TRI(
            output reg  Q = 0,
            input       RST, CP, D);

   table
    //RST       CP      D       :Q      :Q+ ;
      //(1) clear function
      1         ?       ?       :?      :0 ;
      (??)      ?       ?       :?      :- ;
      //0         ?       ?       :?      :- ;

      //(2) capture at negedge
      0         (10)    0       :?      :0 ;
      0         (10)    1       :?      :1 ;
      //possible negedge
      0         (1x)    ?       :?      :- ;
      0         (x0)    ?       :?      :- ;

      //(3) stable at posedge
      0         (0?)    ?       :?      :- ;
      //possible posedge
      0         (x1)    ?       :?      :- ;

      //(4) stable when CP stable
      0         ?       (??)    :?      :- ;

   endtable
endprimitive // D_TRI
















primitive d_latch(q, clear, en, d);
   output       q ;
   reg          q ;
   input        d, en, clear ;

   initial
     q = 0 ;

   table
    //clear     en      d       :q      :q+ ;
      1         ?       ?       :?      :0 ;    //clear
      0         0       ?       :?      :- ;    //hold on

      0         1       0       :?      :0 ;    //q = d
      0         1       1       :?      :1 ;
   endtable
endprimitive


primitive d_latch2(
   output reg   q = 0,
   input        clear, en, d);

   table
    //clear     en      d       :q      :q+ ;
      1         ?       ?       :?      :0 ;    //clear
      0         0       ?       :?      :- ;    //hold on

      0         1       0       :?      :0 ;    //q = d
      0         1       1       :?      :1 ;
   endtable
endprimitive
