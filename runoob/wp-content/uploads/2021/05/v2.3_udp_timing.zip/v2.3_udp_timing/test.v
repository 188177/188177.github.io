`timescale 1ns/1ps

module test ;
   reg  D, CP = 0 ;
   wire Q, QR ;

   always #5 CP = ~CP ;

   initial begin
      D = 0 ;
      #12 D = 1 ;
      #10 D = 0 ;
      #14  D = 1 ;
      #3  D = 0 ;
      #18  D = 0 ;
   end

   D_TRI u_d_trigger(
        .D      (D),
        .CP     (CP),
        .Q      (Q),
        .QR     (QR));


   initial begin
      forever begin
         #100;
         //$display("---gyc---%d", $time);
         if ($time >= 1000) begin
            $finish ;
         end
      end
   end


endmodule // test
