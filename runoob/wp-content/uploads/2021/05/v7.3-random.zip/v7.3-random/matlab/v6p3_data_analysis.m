clear all;close all;clc;
%=======================================================
% data analysis from $dist_erlang in Verilog
%=======================================================
data_erlang1_hex    = textread('data_erlang1.hex', '%s') ;
data_erlang2_hex    = textread('data_erlang2.hex', '%s') ;
data_erlang3_hex    = textread('data_erlang3.hex', '%s') ;
data_erlang30_hex   = textread('data_erlang30.hex', '%s') ;
data_erlang1        = hex2dec(data_erlang1_hex);
data_erlang2        = hex2dec(data_erlang2_hex);
data_erlang3        = hex2dec(data_erlang3_hex);
data_erlang30       = hex2dec(data_erlang30_hex);

num_erlang1  = tabulate(data_erlang1) ;
num_erlang2  = tabulate(data_erlang2) ;
num_erlang3  = tabulate(data_erlang3) ;
num_erlang30 = tabulate(data_erlang30) ;
figure;  plot(num_erlang1(:,1)/6, num_erlang1(:,3));
hold on; plot(num_erlang2(:,1)/6, num_erlang2(:,3), 'r');
hold on; plot(num_erlang3(:,1)/6, num_erlang3(:,3), 'g');
hold on; plot(num_erlang30(:,1)/6, num_erlang30(:,3), 'y');
legend('n=1', 'n=2', 'n=3', 'n=30');