clear all;close all;clc;
%=======================================================
% generating data of Erlang distribution 
%=======================================================
NUM         = 400 ;
EXPECT      = 6 ;
for n=[1, 2, 3, 30]
    lamda   = n/EXPECT;
    t       = (0:NUM-1)*0.1 ;
    pt(n,:) = (lamda).^n *(t).^(n-1)/factorial(n-1) .* exp(-lamda * t) ;
end

figure; plot(t, pt(1,:)*100);
hold on;plot(t, pt(2,:)*100, 'r');
hold on;plot(t, pt(3,:)*100, 'g');
hold on;plot(t, pt(n,:)*100, 'y');
xlabel('t');
ylabel('f(t) / 100%');
legend('n=1', 'n=2', 'n=3', 'n=30');
