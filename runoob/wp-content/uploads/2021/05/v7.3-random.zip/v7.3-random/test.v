`timescale 1ns/1ps

module test ;
   reg          clk ;

   initial begin
      clk = 0 ;
   end
   always #(10/2)   clk = ~clk ;

   //seed var
   integer seed ;
   initial begin
      seed = 2 ;
      #30 ;
      seed = 10 ;
   end
   //no seed
   reg [15:0]   randnum_noseed ;
   always@(posedge clk) begin
      randnum_noseed <= $random();
   end
   //with seed
   reg [15:0]   randnum_wtseed ;
   always@(posedge clk) begin
      randnum_wtseed <= $random(seed);
   end


   //============================ (1.2) =================================
   //with a range
   parameter    MAX_NUM = 512;
   parameter    MIN_NUM = 256;
   //random data within a range
   reg [15:0]   num_range1, num_range2, num_range3 ;
   always@(posedge clk) begin
      num_range1 <= $random() % MAX_NUM;
      num_range2 <= {$random()} % MAX_NUM;
      num_range3 <= MIN_NUM + {$random()} % (MAX_NUM-MIN_NUM+1);
   end


   // ============================ distirbution ==========================
   integer      seed_dis ;
   initial      seed_dis = 0 ;

   //2.1 uniform dis
   reg [15:0]   data_uniform;
   always@(posedge clk) begin
      data_uniform <= $dist_uniform(seed_dis, MIN_NUM, MAX_NUM);
   end

   //2.2 normal dis
   reg [15:0]   data_normal;
   always@(posedge clk) begin
      data_normal <= $dist_normal(seed_dis, 0, 1);
   end

   //2.3 poisson dis
   reg [15:0]   data_poisson;
   always@(posedge clk) begin
      data_poisson <= $dist_poisson(seed_dis, 4);
   end

   //2.4 exp dis
   reg [15:0]   data_exp;
   always@(posedge clk) begin
      data_exp <= $dist_exponential(seed_dis, 1);
   end

   //2.5 chi-square dis
   reg [15:0]   data_chi_sq;
   always@(posedge clk) begin
      data_chi_sq <= $dist_chi_square(seed_dis, 6);
   end

   //2.6 t dis
   reg [15:0]   data_t;
   always@(posedge clk) begin
      data_t <= $dist_t(seed_dis, 5);
   end

   //2.7 Erlang dis
   reg [15:0]   data_erlang;
   always@(posedge clk) begin
      data_erlang  <= $dist_erlang(seed_dis, 3, 6);
   end


   //generating data file of Erlang dis
   integer fd1, fd2, fd3, fd30 ;
   initial begin
      fd1 = $fopen("data_erlang1.hex", "w");
      fd2 = $fopen("data_erlang2.hex", "w");
      fd3 = $fopen("data_erlang3.hex", "w");
      fd30 = $fopen("data_erlang30.hex", "w");
      repeat(1000) begin
         @(posedge clk) ;
         #1 ;
         $fdisplay(fd1, "%h", data_erlang1);
         $fdisplay(fd2, "%h", data_erlang2);
         $fdisplay(fd3, "%h", data_erlang3);
         $fdisplay(fd30, "%h", data_erlang30);
      end
      $fclose(fd1);
      $fclose(fd2);
      $fclose(fd3);
      $fclose(fd30);
   end

   reg [15:0]   data_erlang1;
   reg [15:0]   data_erlang2;
   reg [15:0]   data_erlang3;
   reg [15:0]   data_erlang30;
   always@(posedge clk) begin
      data_erlang1  <= $dist_erlang(seed_dis, 1, 6);
      data_erlang2  <= $dist_erlang(seed_dis, 2, 6);
      data_erlang3  <= $dist_erlang(seed_dis, 3, 6);
      data_erlang30 <= $dist_erlang(seed_dis, 30, 6);
   end


   initial begin
      forever begin
         #100;
         if ($time >= 10000)  $finish ;
      end
   end

endmodule // test
