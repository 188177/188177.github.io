`timescale 1ns/1ps

module test ;
   reg          clk ;

   initial begin
      clk = 0 ;
   end
   always #(10/2)   clk = ~clk ;
   integer fd ;
   integer err, str ;

   //(2) write file
   initial begin
      fd = $fopen("DATA_RD.HEX", "a+");
      err = $ferror(fd, str);
      if (!err) begin
         $fdisplay(fd, "New data1: %h", fd) ;
         $fdisplay(fd, "New data2: %h", str) ;
         $fdisplay(fd, "New data3: %h", err) ;
         //$fwrite(fd, "New data3: %h", err) ;
      end
      $fclose(fd);
   end


   //(1)open/close file
   integer fd1, fd2 ;
   integer err1, err2 ;
   reg [320:0] str1, str2 ;
   initial begin
      #10 ;
      //existing file
      fd1 = $fopen("DATA_RD.HEX", "r");
      err1 = $ferror(fd1, str1);
      $display("File1 descriptor is: %h.", fd1 );
      $display("Error1 number is: %h.", err1 );
      $display("Error1 info is: %s.", str1 );
      $fclose(fd1);
      //not existing file
      fd2 = $fopen("../tb/FILE_NOEXIST.HEX", "r");
      err2 = $ferror(fd2, str2);
      $display("File2 descriptor is: %h.", fd2 );
      $display("Error2 number is: %h.", err2 );
      $display("Error2 info is: %s.", str2 );
      $fclose(fd2);
   end


   //(3) write string
   reg [299:0] str_swrite;
   reg [299:0] str_sformat;
   reg [63:0] str_buf ;
   integer    len, age ;
   initial begin
      #20 ;
      str_buf   = "runoob!" ;
      age       = 9 ;

      $swrite(str_swrite, "%s age is %d", str_buf, age) ;
      $display("%s", str_swrite);
      $swrite(str_swrite, "years ", "old.") ;
      $display("%s", str_swrite);
      //err test
      $swrite(str_swrite, age) ;
      $display("$swrite err test: %d", str_swrite);

      $display();
      $sformat(str_sformat, "I have learnt in %s", str_buf) ;
      $display("%s", str_sformat);
      len = $sformat(str_sformat, "for 4 years!") ;
      $display("%s", str_sformat);
      $display("$sformat len: %d", len);
      //err test
      $sformat(str_sformat, "for", "4", "years!") ;
      $display("$sformat err test: %s", str_sformat);
   end


   //(4.1) read char
   integer      i ;
   reg [31:0]   char_buf ;
   initial begin
      #30 ;
      fd = $fopen("DATA_RD.HEX", "r");
      $write("Read char: ");
      err = $ferror(fd, str);
      if (!err) begin
         for (i=0; i<13; i++) begin
            char_buf[7:0] = $fgetc(fd) ;
            $write("%c", char_buf[7:0]) ;
         end
         $write(".\n") ;
      end

      $ungetc("1", fd) ;
      $ungetc("2", fd) ;
      $ungetc("3", fd) ;
      char_buf[7:0]   = $fgetc(fd) ;
      char_buf[15:8]  = $fgetc(fd) ;
      char_buf[23:16] = $fgetc(fd) ;
      char_buf[31:24] = $fgetc(fd) ;
      $display("Read char after $ungetc: %s", char_buf);
      $fclose(fd);
   end


   //(4.2) read line
   integer      code ;
   reg [99:0]   line_buf [9:0] ;
   initial begin
      #31 ;
      fd = $fopen("DATA_RD.HEX", "r");
      err = $ferror(fd, str);
      if (!err) begin
         for (i=0; i<6; i++) begin
            code = $fgets(line_buf[i], fd) ;
            $display("Get line data%d: %s", i, line_buf[i]) ;
            //$display("Get length%d: %s", i, code) ;
         end
      end
      $display("Show hex line data%d: %h", 2, line_buf[2]) ;
      $display("Show hex line data%d: %h", 4, line_buf[4]) ;
      $fclose(fd) ;
   end


   //(4.3) $fscanf/$sscanf
   reg [31:0]   data_buf [9:0] ;
   reg [63:0]   string_buf [9:0] ;
   reg [31:0]   data_get ;
   reg [63:0]   data_test ;
   initial begin
      #32 ;
      fd = $fopen("DATA_RD.HEX", "r");
      err = $ferror(fd, str);
      if (!err) begin
         for (i=0; i<4; i++) begin
            code = $fscanf(fd, "%h", data_buf[i]);
            $display("$fscanf read data%d: %h", i, data_buf[i]) ;
         end
         for (i=4; i<6; i++) begin
            code = $fscanf(fd, "%s", string_buf[i]);
            $display("$fscanf read data%d: %s", i, string_buf[i]) ;
         end
      end

      //(1) $sscanf: direct string as input
      data_test = "fedcba98" ;
      code = $sscanf(data_test, "%h", data_get);
      $display("$sscanf read direct data: %h", data_get) ;

      //(2) $sscanf: trun source-vars into string
      code = $sformat(data_test, "%h", data_buf[2]);
      code = $sscanf(data_test, "%h", data_get);
      //code = $sscanf(data_buf[2], "%h", data_get);
      $display("$sscanf read data2: %h", data_get) ;

      data_get = data_buf[2];
      $display("$sscanf read data2: %h", data_get) ;
      $fclose(fd) ;
   end

   //(4.4) $fread
   reg [71:0]   bin_buf [3:0] ;
   reg [143:0]  bin_reg ;
   initial begin
      #33 ;
      fd = $fopen("DATA_RD.HEX", "r");
      err = $ferror(fd, str);
      if (!err) begin
         code = $fread(bin_buf, fd, 0, 4);
         $display("$fread read data %h", bin_buf[0]) ;
         $display("$fread read data %h", bin_buf[1]) ;
         $display("$fread read data %s", bin_buf[2]) ;
         $display("$fread read data %s", bin_buf[3]) ;
      end

      fd = $fopen("DATA_RD.HEX", "r");
      code = $fread(bin_reg, fd);
      $display("$fread read data %h", bin_reg) ;
      $display();
      $display();
      $fclose(fd) ;
   end


   // 5 file position
   reg [31:0]   data4 ;
   reg [199:0]  str_long ;
   integer      pos ;
   initial begin
      #40 ;
      fd = $fopen("DATA_RD.HEX", "r");
      err = $ferror(fd, str);
      if (!err) begin
         //first read
         code   = $fscanf(fd, "%h", data4);
         pos    = $ftell(fd);
         $display("Position after read: %d", pos) ;
         $display("1st read data: %h", data4) ;

         //type = 0
         code   = $fseek(fd, 4, 0) ;
         code   = $fscanf(fd, "%h", data4);
         pos    = $ftell(fd);
         $display("type 0: current position: %d", pos) ;
         $display("type 0: read data: %h", data4) ;
         //type = 1
         code   = $fseek(fd, 4, 1) ;
         code   = $fscanf(fd, "%h", data4);
         pos    = $ftell(fd);
         $display("type 1: current position: %d", pos) ;
         $display("type 1: read data: %h", data4) ;
         //type = 2
         code   = $fseek(fd, -(96-31), 2) ;
         code   = $fscanf(fd, "%h", data4);
         pos    = $ftell(fd);
         $display("type 2: current position: %d", pos) ;
         $display("type 2: read data: %h", data4) ;

         //rewind read
         code   = $rewind(fd) ;
         pos    = $ftell(fd);
         $display("Position after $rewind: %d", pos) ;
         //read all content of file
         while (!$feof(fd)) begin
            code   = $fgets(str_long, fd);
            $write("Read : %s", str_long) ;
         end
         $display() ;
         $display() ;
         $fclose(fd) ;
      end
   end


   //6 load mem
   reg [31:0]   mem_load [3:0] ;
   initial begin
      #50 ;
      $readmemh("./DATA_WITHNOTE.HEX", mem_load);
      $display("Read memory1: %h", mem_load[0]) ;
      $display("Read memory2: %h", mem_load[1]) ;
      $display("Read memory3: %h", mem_load[2]) ;
      $display("Read memory4: %h", mem_load[3]) ;
   end



   initial begin
      forever begin
         #100;
         if ($time >= 10000)  $finish ;
      end
   end

endmodule 
