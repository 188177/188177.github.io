module D_TRI(
            input       D, CP,
            output      Q, QR);

   //part1, not gate
   wire         CPN, DN ;
   not          (CPN, CP);
   not          (DN, D);

   //part2, master trigger
   wire         G3O, G4O ;
   nand_my      (G3O, D, CP);
   nand_my      (G4O, DN, CP);
   wire         G1O, G2O ;
   nand_my      (G1O, G3O, G2O);
   nand_my      (G2O, G4O, G1O);

   //part3, slave trigger
   wire         G7O, G8O ;
   nand_my      (G7O, G1O, CPN);
   nand_my      (G8O, G2O, CPN);
   wire         G5O, G6O ;
   nand_my      (G5O, G7O, G6O);
   nand_my      (G6O, G8O, G5O);

   assign       Q = G5O ;
   assign       QR = G6O ;

endmodule // D_TRI


primitive nand_my(out, a, b);
   output       out ;
   input        a, b ;

   table
    //a         b       :       out ;
      0         ?       :       1 ;
      ?         0       :       1 ;
      1         1       :       0 ;

      1         x       :       x ;
      x         1       :       x ;
   endtable
endprimitive


primitive nand_my2(
   output       out,
   input        a, b);

   table
    //a         b       :       out ;
      0         0       :       1 ;
      0         1       :       1 ;
      1         0       :       1 ;
      1         1       :       0 ;

      0         x       :       1 ;
      x         0       :       1 ;
   endtable
endprimitive
