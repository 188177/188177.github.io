module and_gate(
   output  Z,
   input   A, B);

   assign Z = A & B ;

   specify
      specparam t_rise = 1.3:1.5:1.7 ;
      specparam t_fall = 1.1:1.3:1.6 ;
      (A, B  *> Z) = (t_rise, t_fall) ;
   endspecify

 endmodule
