`timescale 1ns/1ps
module test ;
   reg [1599:0]         str_my ;
   reg [31:0]           int_my ;
   reg                  flagh ;

   //send_my
   integer              i = 1599;
   integer              j = 1599;
   reg [7:0]            str_tmp ;
   initial begin
      flagh = 0 ;
      forever begin
         //@(posedge clk) ;
         #20 ;
         $send_my(flagh, str_my, int_my);
         if (flagh) begin
            #1 ;
            for(i=1599; i>=0; i= i-8) begin
               if (str_my[i -: 8] != 0)
                 break ;
            end
            $display("--DEBUG--- Valid data number: %d", i);
            //$display("--ERR--- String data structure: %h", str_my);

            //display
            if (i<=791) begin
               $display("--ERR--- PLEASE INPUT VALID STRING INFO!!!");
               $display("--ERR--- Default data number: %d", i);
               $display("--ERR--- String data structure: %h", str_my);
            end
            else begin
               $write("---YYY---");
               for(j=i; j>=0; j= j-8) begin
                  str_tmp = str_my[j -: 8] ;
                  if (str_tmp == "") begin
                     break ;
                  end
                  else begin
                     $write("%s", str_tmp);
                  end
               end
               $write("%h \n", int_my);
            end

            /* $display cannot support str_my[i:144]
            else begin
               $display("--YYY--- %s%h", str_my[i : j], int_my);
            end
             */
            flagh = 0 ;
         end
      end
   end

   //c print
   initial begin
      #100 ;
      $call_c_print(1);
      #100 ;
      $call_c_print(2);
      #100 ;
      $call_c_print(3);
   end


   //stop
   initial begin
      forever begin
         #10000;
         if ($time >= 300)  $finish ;
      end
   end

endmodule // test
