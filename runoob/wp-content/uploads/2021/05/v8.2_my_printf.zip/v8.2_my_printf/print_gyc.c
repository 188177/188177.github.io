#include "veriuser.h"

char            *str_mes ;
unsigned int    int_mes ;
int             flags = 0;

//======================= define print_my() used in C ==========================
void print_my(char * str_send, unsigned int int_send){
    str_mes  = str_send ;
    int_mes  = int_send ;
    flags    = 1 ;
}

void call_c_print(){
    if (tf_getp(1) == 1)
        print_my("It's the first successfull print: ", 0x20170714);
    else if (tf_getp(1) == 2)
        print_my("2nd: ", 0x09070602);
    else
        print_my("", 0x1); //err
}

//===================== define send_my() used in rtl ========================
void byte2hexstr(char* str, char* dest, int len)
{
    char tmp;
    int  i ;
    char stb[16] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
    for (i = 0; i < len; i++){
        tmp = str[i];
        dest[i * 2] = stb[tmp >> 4];
        dest[i * 2 + 1] = stb[tmp & 15];
    }
    return;
}


char            str_mes_format[200] ;
void send_my(){
    int i = 0 ;
    if (flags && tf_nump()==3) {
        flags = 0 ;
        byte2hexstr(str_mes, str_mes_format, 100);
        //send string and integer message
        tf_strdelputp(2, 1600, 'H', str_mes_format, 0, 0);
        tf_putp(3, int_mes);
        tf_putp(1, 1) ; //display flag, first arg = 1

        //for(i=0; i<20; i++) {
        //        io_printf("Data Conversion: %0x \n", str_test[i]);
        //}
        //io_printf("Data Conversion: %s \n", str_test);
        //io_printf("Data Conversion: %0x \n", str_send);
        //io_printf("Data Conversion: %s \n", str_send);
    }
}
