//===========================================
//1 multiplier, high speed
module  mul1_hs
    (
        input           clk ,           //200MHz
        input           rstn ,
        input           en  ,
        input [3:0]     mul1 ,          //data in
        input [3:0]     mul2 ,          //data in
        output          dout_en ,
        output [8:0]    dout
     );

   reg                  flag ;
   reg                  en_r ;
   always @(posedge clk or negedge rstn) begin
      if (!rstn) begin
         flag   <= 1'b0 ;
         en_r   <= 1'b0 ;
      end
      else if (en) begin
         flag   <= ~flag ;
         en_r   <= 1'b1 ;
      end
      else begin
         flag   <= 1'b0 ;
         en_r   <= 1'b0 ;
      end
   end

   wire [7:0]           result = mul1 * mul2 ;

   // data output en
   reg [7:0]            res1_r, res2_r ;
   always @(posedge clk or negedge rstn) begin
      if (!rstn) begin
         res1_r         <= 'b0 ;
         res2_r         <= 'b0 ;
      end
      else if (en & !flag) begin
         res1_r         <= result ;
      end
      else if (en & flag) begin
         res2_r         <= result ;
      end
   end

   assign dout_en = en_r & !flag ;
   assign dout = res1_r + res2_r ;

endmodule

//===========================================
// 2 multiplier2, low speed
module  mul2_ls
    (
        input           clk ,           //100MHz
        input           rstn ,
        input           en  ,
        input [3:0]     mul1 ,          //data in
        input [3:0]     mul2 ,          //data in
        input [3:0]     mul3 ,          //data in
        input [3:0]     mul4 ,          //data in
        output          dout_en,
        output [8:0]    dout
     );

   wire [7:0]           result1 = mul1 * mul2 ;
   wire [7:0]           result2 = mul3 * mul4 ;

   //en delay
   reg                  en_r ;
   always @(posedge clk or negedge rstn) begin
      if (!rstn) begin
         en_r           <= 1'b0 ;
      end
      else begin
         en_r           <= en ;
      end
   end

   // data output en
   reg [7:0]            res1_r, res2_r ;
   always @(posedge clk or negedge rstn) begin
      if (!rstn) begin
         res1_r         <= 'b0 ;
         res2_r         <= 'b0 ;
      end
      else if (en) begin
         res1_r         <= result1 ;
         res2_r         <= result2 ;
      end
   end
   assign dout          = res1_r + res2_r ;
   assign dout_en       = en_r ;

endmodule
