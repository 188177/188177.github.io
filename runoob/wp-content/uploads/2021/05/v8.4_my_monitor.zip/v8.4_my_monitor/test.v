`timescale 1ns/1ps

module test ;

   reg          rstn, clk ;
   wire [3:0]   cnt ;
   wire         cout ;

   initial begin
      rstn      = 0 ;
      clk       = 0 ;
      #19.8;
      rstn      = 1 ;
   end
   always #5 clk = ~clk ;

   counter10 u_cnt(
     .rstn      (rstn),
     .clk       (clk),
     .cnt       (cnt),
     .cout      (cout));

   initial begin
      $my_monitor(test.rstn, test.clk, test.cnt, test.cout);
   end

   initial begin
      forever begin
         #100;
         if ($time >= 300)  $finish ;
      end
   end

endmodule // test
