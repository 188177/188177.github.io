#include "acc_user.h"

handle  hand_rstn, hand_clk, hand_cnt, hand_cout ;
int cnt_soft  = 0 ;
int cout_soft = 0 ;

void act_monitor(){
    p_acc_value value ;
    //rtl data
    char *rstn_rtl_str = acc_fetch_value(hand_rstn, "%d", value);
    char *clk_rtl_str  = acc_fetch_value(hand_clk, "%d", value);
    char *cnt_rtl_str  = acc_fetch_value(hand_cnt, "%d", value);
    char *cout_rtl_str = acc_fetch_value(hand_cout, "%d", value);

    //string -> int
    int rstn_rtl       = atoi(rstn_rtl_str) ;
    int clk_rtl        = atoi(clk_rtl_str) ;
    int cnt_rtl        = atoi(cnt_rtl_str) ;
    int cout_rtl       = atoi(cout_rtl_str) ;

    //soft counter
    if (!rstn_rtl) {
        cnt_soft    = 0 ;
        cout_soft   = 0 ;
        io_printf("---iii--- Reset state! \n");
    }
    else if (rstn_rtl && clk_rtl) {
        if (cnt_soft == 9) {
            cnt_soft    = 0 ;
        }
        else {
            cnt_soft    = cnt_soft + 1 ;
        }
    }
    cout_soft = cnt_soft == 9 ? 1 : 0 ;

    //soft check
    if (!clk_rtl && rstn_rtl) {
        if ((cnt_soft != cnt_rtl) || (cout_soft != cout_rtl)) {
            io_printf("--Err--- rtl cnt: %d, and soft cnt: %d\n", cnt_rtl, cnt_soft);
            io_printf("--Err--- rtl cout: %d, and soft cout: %d\n", cout_rtl, cout_soft);
        }
        else if (cnt_soft == 9)  {
            io_printf("--Monitor--- rtl and soft cnt: %d\n", cnt_soft);
            io_printf("--Monitor--- rtl and soft cout: %d\n", cout_soft);
        }
    }
}


void my_monitor() {
    acc_initialize();
    hand_rstn   = acc_handle_tfarg(1);
    hand_clk    = acc_handle_tfarg(2);
    hand_cnt    = acc_handle_tfarg(3);
    hand_cout   = acc_handle_tfarg(4);
    //"#define VCL_VERILOG_LOGIC 2" in acc_user.h
    //Indicates the VCL callback mechanism shall report
    //information on logic value changes
    acc_vcl_add(hand_clk, act_monitor, null, vcl_verilog_logic);
    acc_close();
}
