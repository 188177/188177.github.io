module full_adder1(
   input   Ai, Bi, Ci,
   output  So, Co);

   assign So = Ai ^ Bi ^ Ci ;
   assign Co = (Ai & Bi) | (Ci & (Ai | Bi));

   specify
      (Ai, Bi, Ci *> So) = 1.1 ;
      (Ai, Bi     *> Co) = 1.3 ;
      (Ci         => Co) = 1.2 ;
   endspecify
endmodule

module D8(
    input       [7:0]   d ,
    input               clk ,
    output reg [7:0]    q);

   always @(posedge clk)
     q <= d ;

   specify
      $setup(d, posedge clk, 2);
      $hold(posedge clk, d, 3);
      //$setuphold(posedge clk, d, 2, 3);
      (d,clk *> q) = 0.3 ;
   endspecify

endmodule


module full_adder8(
     input [7:0]   a ,   //adder1
     input [7:0]   b ,   //adder2
     input         c ,   //input carry bit

     output [7:0]  so ,  //adding result
     output        co    //output carry bit
     );

   wire [7:0]      co_temp ;
   full_adder1  u_adder0(
                         .Ai     (a[0]),
                         .Bi     (b[0]),
                         .Ci     (c==1'b1 ? 1'b1 : 1'b0),
                         .So     (so[0]),
                         .Co     (co_temp[0]));

   genvar          i ;
   generate
      for(i=1; i<=7; i=i+1) begin: adder_gen
         full_adder1  u_adder(
                              .Ai     (a[i]),
                              .Bi     (b[i]),
                              .Ci     (co_temp[i-1]),
                              .So     (so[i]),
                              .Co     (co_temp[i]));
      end
   endgenerate
   assign co    = co_temp[7] ;

endmodule