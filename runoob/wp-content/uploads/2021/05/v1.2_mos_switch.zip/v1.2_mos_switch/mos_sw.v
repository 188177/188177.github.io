module PADUP(
   //DIN, pad driver when pad configured as output
   //OEN, pad direction(1-input, o-output)
   input        DIN, OEN ,
   inout        PAD ,
   //pad load when pad configured as input
   output       DOUT
  );

   //input:(not effect pad external input logic), output: DIN->PAD
   bufif0 (PAD, DIN, OEN) ;     //0-output
   bufif1 (DOUT, PAD, OEN) ;    //1-input
   pullup (PAD);
   //pulldown (PAD);
endmodule


module PADDOWN(
   input        DIN, OEN ,
   inout        PAD ,
   output       DOUT
  );

   //input:(not effect pad external input logic), output: DIN->PAD
   bufif0 (PAD, DIN, OEN) ;     //0-output
   bufif1 (DOUT, PAD, OEN) ;    //1-input
   pulldown (PAD);
endmodule











module mos_sw
    (
        input           IN1,
        input           CTRL1, CTRL2,
        input           NCTRL, PCTRL,
        output          OUTX, OUTY, OUTZ,
        output          OUTX1, OUTY1, OUTZ1);


   //tri
   pmos pmos1           (OUTX, IN1, CTRL1) ;
   //no instantiation name
   nmos                 (OUTX1, IN1, CTRL2) ;

   //coms
   cmos c1              (OUTY, IN1, NCTRL, PCTRL) ;
   //no instantiation name
   cmos                 (OUTY1, IN1, NCTRL, PCTRL) ;

   //the same 2-way instantiation of cmos
   cmos c2              (OUTZ, IN1, NCTRL, PCTRL) ;
   nmos n2              (OUTZ1, IN1, NCTRL) ;
   pmos p2              (OUTZ1, IN1, PCTRL) ;

   supply1              VDD ;
   supply0              GND ;
   wire                 siga = VDD ;
   wire                 sigb = GND ;


endmodule // mos_gate
