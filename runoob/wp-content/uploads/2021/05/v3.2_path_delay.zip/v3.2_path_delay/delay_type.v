module D_TRI(
            input       D, CP,
            output      Q, QR);
endmodule


//distributed
/*
module and4(
   output       out,
   input        a, b, c, d);

   wire         an1, an2 ;
   and #1       (an1, a, b);
   and #2       (an2, c, d);
   and #1.5     (out, an1, an2);
endmodule
*/

//lumped
/*
module and4(
   output       out,
   input        a, b, c, d);

   wire         an1, an2 ;
   assign #1    an1 = a & b ;
   assign #2    an2 = c & d ;
   assign #1.5  out = an1 & an2 ;
endmodule
 */

//path delay
module and4(
   output       out,
   input        a, b, c, d);

   specify
      specparam ab_2_out = 2.5 ;
      specparam cd_2_out = 2.5 ;

      (a => out) = ab_2_out ;
      (b => out) = ab_2_out ;
      (c => out) = cd_2_out ;
      (d => out) = cd_2_out ;
   endspecify

   wire         an1, an2 ;
   and          (an1, a, b);
   and          (an2, c, d);
   and          (out, an1, an2);
endmodule


//full connection
/*
module and4(
   output       out,
   input        a, b, c, d);

   specify
      (a,b *> out) = 2.5 ;
      (c,d *> out) = 3.5 ;
   endspecify

   wire         an1, an2 ;
   and          (an1, a, b);
   and          (an2, c, d);
   and          (out, an1, an2);
endmodule
*/


//parallel connect
module paral_conn(
    input [3:0]         d,
    output [3:0]        q);

   /*
   specify
      (d => q) = 3 ;
   endspecify
    */

   specify
      (d[0] => q[0]) = 3 ;
      (d[1] => q[1]) = 3 ;
      (d[2] => q[2]) = 3 ;
      (d[3] => q[3]) = 3 ;
   endspecify

   assign q = d & 0101 ;

endmodule // paral_conn


module if_path(
               output       out,
               input        a, b, c, d);

   specify
      if (a)    (a => out) = 2.5 ;
      if (~a)   (a => out) = 1.5 ;

      if (b & c)        (b => out) = 2.5 ;
      if (!(b & c))     (b => out) = 1.5 ;

      if ({c, d} == 2'b01)
                (c,d *> out) = 3.5 ;
      ifnone    (c,d *> out) = 3 ;
   endspecify

   wire                     an1, an2 ;
   and          (an1, a, b);
   and          (an2, c, d);
   and          (out, an1, an2);
endmodule // if_path




module gate_path(
   input        d,
   input        clk ,
   output reg   q);

   //(1) one parameter
/* -----\/----- EXCLUDED -----\/-----
   specify
      specparam t_delay = 1.5 ;
      (clk => q) = t_delay ;
   endspecify
 -----/\----- EXCLUDED -----/\----- */

/* -----\/----- EXCLUDED -----\/-----
   //(2) 2 parameter
   specify
      specparam t_rise = 1.5, t_fall = 2 ;
      (clk => q) = (t_rise, t_fall) ;
   endspecify
 -----/\----- EXCLUDED -----/\----- */


   //(3) rising/falling/turnoff
/* -----\/----- EXCLUDED -----\/-----
   specify
      specparam t_rise = 1.5 ;
      specparam t_fall = 2 ;
      specparam t_turnoff = 1.8 ;
      (clk => q) = (t_rise, t_fall, t_turnoff) ;
   endspecify
 -----/\----- EXCLUDED -----/\----- */

/* -----\/----- EXCLUDED -----\/-----
   //(4)
   specify
      specparam t_01 = 1.5, t_10 = 2,   t_0z = 1.8 ;
      specparam t_z1 = 2,   t_1z = 2.2, t_z0 = 2.1 ;
      (clk => q) = (t_01, t_10, t_0z, t_z1, t_1z, t_z0) ;
   endspecify
 -----/\----- EXCLUDED -----/\----- */

/* -----\/----- EXCLUDED -----\/-----
   //12 parameters
   specify
      specparam t_01 = 1.5, t_10 = 2,   t_0z = 1.8 ;
      specparam t_z1 = 2,   t_1z = 2.2, t_z0 = 2.1 ;
      specparam t_0x = 1.1, t_x1 = 1.2, t_1x = 2.1 ;
      specparam t_x0 = 2,   t_xz = 2  , t_zx = 2.1 ;

      (clk => q) = (t_01, t_10, t_0z, t_z1, t_1z, t_z0,
                    t_0x, t_x1, t_1x, t_x0, t_xz, t_zx) ;
   endspecify
 -----/\----- EXCLUDED -----/\----- */


   //min/typical/max
   specify
      specparam t_rise    = 1:1.5:1.8;
      specparam t_fall    = 1:1.8:2 ;
      specparam t_turnoff = 1.1:1.2:1.3 ;
      (clk => q) = (t_rise, t_fall, t_turnoff) ;
   endspecify

   always@(posedge clk)
     q <= d ;

endmodule
