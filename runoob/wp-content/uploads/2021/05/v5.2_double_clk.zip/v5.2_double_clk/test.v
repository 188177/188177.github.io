`timescale 1ns/1ps

module test ;
   reg          clk_100mhz, clk_200mhz ;
   reg          rstn ;
   reg          csn ;
   reg [7:0]    din ;
   reg          din_en ;
   wire [7:0]   dout ;
   wire         dout_en ;

   always #(2.5)    clk_200mhz  = ~clk_200mhz ;
   always @(posedge clk_200mhz)
                    clk_100mhz  = ~clk_100mhz ;

   initial begin
      clk_100mhz  = 0 ;
      clk_200mhz  = 0 ;
      rstn        = 0 ;
      din         = 0 ;
      din_en      = 0 ;
      csn         = 0 ;
      //start work
      #11 rstn    = 1 ;
      @(negedge clk_100mhz) ;
      din_en      = 1 ;
      #0.2 ;
      csn         = 1 ;
      //generate csn
      forever begin
         @(posedge clk_100mhz) ;
         #0.2 ;
         csn = 0 ;      //insert delay for select
         @(negedge clk_100mhz) ;
         #0.2 ;
         csn = 1 ;
      end
   end

   always @(negedge clk_200mhz) begin
      din <= {$random()} % 8'hFF ;
   end

   double_rate u_double_rate(
     .rstn      (rstn),
     .clk       (clk_100mhz),
     .csn       (csn),
     .din       (din),
     .din_en    (din_en),
     .dout      (dout),
     .dout_en   (dout_en));


   initial begin
      forever begin
         #100;
         if ($time >= 10000)  $finish ;
      end
   end

endmodule 
