`timescale 1ns/1ps

module test ;
   reg          clk ;

   initial begin
      clk = 0 ;
   end
   always #(10/2)   clk = ~clk ;

   //$display
   reg [3:0]         num ;
   initial begin
      num  = 1 ;
      $display("This is a test.");
      $display("This is a test number: %b.", num);
      $display("This is a test number: ", num, "!!!");
   end

   //$write
   initial begin
      #4 ;
      $write("This is a test");
      $write("number: %b", num);
      $write("!!!\n");
   end

   //$strobe
   reg [3:0]  a ;
   initial begin
      a = 1 ;
      #1 ;
      a <= a + 1 ;
      $display("$display excuting result: %d.", a);
      $strobe("$strobe excuting result: %d.", a);
      #1 ;
      $display();
      $display("$display excuting result: %d.", a);
      $strobe("$strobe excuting result: %d.", a);
   end

   integer  i ;
   initial begin
      #8 ;
      for (i=0; i<4; i=i+1) begin
         $display("Run times of $display: %d.", i);
         $strobe("Run times of $strobe: %d.", i);
      end
   end


   //$monitor
   reg [3:0]    cnt ;
   initial begin
      cnt = 3 ;
      forever begin
         # 5 ;
         if (cnt<7) cnt = cnt + 1 ;
      end
   end

   initial begin
      $monitor("Counter change to value %d at the time %t.", cnt, $time);
   end



   initial begin
      forever begin
         #100;
         if ($time >= 10000)  $finish ;
      end
   end

endmodule // test
