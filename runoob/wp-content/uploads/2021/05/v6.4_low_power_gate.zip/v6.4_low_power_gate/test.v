`timescale 1ns/1ns

module test ;

   //signals declaration
   reg          rstn ;
   reg          clk ;
   reg          clken ;
   reg          wr_en ;
   reg [3:0]    addr ;
   reg [7:0]    data ;
   wire [7:0]   q ;

   initial begin
      rstn      = 0 ;
      #7 rstn   = 0 ;
   end

   always begin
      #50 clk = 0 ;
      #50 clk = 1 ;
   end

   //data logic
   initial begin
      clken     = 0 ;
      wr_en     = 0 ;
      addr      = 4'h3 ;
      data      = 8'h31 ;
      # 53 ;
      //(1) normal write and read
      clken     = 1 ;
      wr_en     = 1 ;
      repeat(9) begin
         @(negedge clk) ;
         data   = data + 1 ;
         addr   = addr + 1 ;
      end
      @(negedge clk) ;
      clken     = 0 ;
      wr_en     = 0 ;

      //read
      #211;
      addr      = 4'h3 ;
      clken     = 1 ;
      repeat(9) begin
         @(negedge clk) ;
         addr   = addr + 1 ;
      end
      @(negedge clk) ;
      clken     = 0 ;

      //(2) jitter at the end of read
      #985;
      addr      = 4'h3 ;
      clken     = 1 ;
      repeat(9) begin
         @(negedge clk) ;
         addr   = addr + 1 ;
      end
      @(negedge clk) ;
      clken     = 0 ;
      #20 clken = 1 ;
      #21 clken = 0 ;
      #31 clken = 1 ;
      #13 clken = 0 ;
   end // initial begin


   clkgate_basic u_ram_clkgate
    (
        .clk    (clk),
        .clken  (clken),
        .rstn   (rstn),
        .wr_en  (wr_en),
        .addr   (addr),
        .data   (data),
        .q      (q)
     );

   //simulation finish
   always begin
      #100;
      if ($time >= 10000)  begin
         #1 ;
         $finish ;
      end
   end

endmodule // test
