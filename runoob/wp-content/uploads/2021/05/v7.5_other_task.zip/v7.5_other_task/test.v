`timescale 1ns/1ps

module test ;
   reg          clk ;
   initial begin
      clk = 0 ;
   end
   always #(10/2)   clk = ~clk ;

   /*
   //change timescale
   initial begin
      # 10 ;
      $timeformat(-12, 5, " my-ps", 15) ;
   end

   initial begin
      # 5 ;
      $printtimescale() ;
      $display("Time before resetup: %t", $time);
      # 10 ;
      $printtimescale() ;
      $display("Time after resetup: %t", $time);
   end
    */

   //$time
   initial begin
      #10;
      $display("$time output1: %t", $time);
      $display("$stime output1: %t", $stime);
      $display("$realtime output1: %t", $realtime);
      #3.2;
      $display("$time output2: %t", $time);
      $display("$stime output2: %t", $stime);
      $display("$realtime output2: %t", $realtime);
      #5.6;
      $display("$time output2: %t", $time);
      $display("$stime output2: %t", $stime);
      $display("$realtime output2: %t", $realtime);
   end


   //command
   initial begin
      if ($test$plusargs("DISPLAY_CTRL")) begin
          $display("Display simulation information!!!");
      end
   end

   reg  [1:0]   display_sel ;
   initial begin
      if ($value$plusargs("INFO_SEL=%b", display_sel)) begin
          $display("Parameter transfer succeeds!!!");
      end
      else begin
         display_sel = 2'b0 ;
      end
   end
   initial begin
      #1 ;
      if (display_sel == 2'b01)
          $display("You have selected Runoob!!!");
      else if (display_sel == 2'b10)
          $display("You have selected Verilog!!!");
      else if (display_sel == 2'b11)
          $display("You have selected Me!!!");
      else
          $display("What do you really what???");
   end




   initial begin
      forever begin
         #100;
         if ($time >= 10000) begin
            $finish(1) ;
         end
      end
   end

endmodule // test
