module D_TRI(
            input       D, CP,
            output      Q, QR);

   parameter RISE_TIME = 0.11 ;
   parameter FALL_TIME = 0.07 ;

   //part1, not gate
   wire         CPN, DN ;
   not  #(RISE_TIME, FALL_TIME)         (CPN, CP);
   not  #(RISE_TIME, FALL_TIME)         (DN, D);

   //part2, master trigger
   wire         G3O, G4O ;
   nand #(RISE_TIME, FALL_TIME)         (G3O, D, CP);
   nand #(RISE_TIME, FALL_TIME)         (G4O, DN, CP);
   wire #(RISE_TIME, FALL_TIME)         G1O, G2O ;
   nand #(RISE_TIME, FALL_TIME)         (G1O, G3O, G2O);
   nand #(RISE_TIME, FALL_TIME)         (G2O, G4O, G1O);

   //part3, slave trigger
   wire         G7O, G8O ;
   nand  #(RISE_TIME, FALL_TIME)        (G7O, G1O, CPN);
   nand  #(RISE_TIME, FALL_TIME)        (G8O, G2O, CPN);
   wire         G5O, G6O ;
   nand  #(RISE_TIME, FALL_TIME)        (G5O, G7O, G6O);
   nand  #(RISE_TIME, FALL_TIME)        (G6O, G8O, G5O);

   assign       Q = G5O ;
   assign       QR = G6O ;

endmodule






module gate_delay(
   input        IN1, IN2,
   input        CTRL ,
   output       OUT1, OUT2, OUT3,
   inout        inout1, inout2,
   inout        inout3, inout4
  );

   /*
   //rise, fall and turn-off delay are all 1
   and #(1)             (OUT1, IN1, IN2) ;
   //rise delay = 2.1, fall dalay = 2, trun-off delay = 2
   or  #(2.1, 2)        (OUT2, IN1, IN2) ;
   //rise delay = 2, fall dalay = 1, trun-off delay = 1.3
   bufif0 #(2, 1, 1.3)  (OUT3, IN1, CTRL) ;
    */

   //turn-on and turn-off delay are all 1
   tranif0 #(1)         (inout1, inout2, CTRL);
   //turn-on delay = 1, turn-off delay = 1.2
   tranif1 #(1, 1.2)    (inout3, inout4, CTRL);


   //min delay = 1, typical delay = 2, max delay = 3 for all delay type
   and #(1:2:3)             (OUT1, IN1, IN2) ;

   //min = 1,        typical = 2,        max = 3 for rising delay
   //min = 3,        typical = 4,        max = 5 for falling delay
   //min = min(1,3), typical = min(2,4), max = min(3,5) for turn-off delay
   or  #(1:2:3, 3:4:5)        (OUT2, IN1, IN2) ;

   //min = 1,        typical = 2,        max = 3 for rising delay
   //min = 3,        typical = 4,        max = 5 for falling delay
   //min = 2,        typical = 3,        max = 4 for turn-off delay
   bufif0 #(1:2:3, 3:4:5, 2:3:4)  (OUT3, IN1, CTRL) ;

endmodule
