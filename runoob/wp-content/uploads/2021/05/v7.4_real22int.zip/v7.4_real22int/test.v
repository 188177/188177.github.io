`timescale 1ns/1ps

module test ;

   //real, bits
   reg [63:0]   num_bits ;
   initial begin
      num_bits  = 64'h4002_8000_0000_0000 ;
      $display("-14.13 -> hex: %h", $realtobits(-13.14));
      $display("64'h4002_8000_0000_0000 -> real: %f", $bitstoreal(num_bits));
      //$display("test: %h", $realtobits(14));
   end

   //$itor, $rtoi
   initial begin
      $display();
      $display("Real to integer: %h", $rtoi(13.14));
      $display("Display integer in float: %f", 1001);
      $display("Integer to real: %f", $itor(1001));
   end

   initial begin
      forever begin
         #100;
         if ($time >= 10000)  $finish ;
      end
   end

endmodule // test
