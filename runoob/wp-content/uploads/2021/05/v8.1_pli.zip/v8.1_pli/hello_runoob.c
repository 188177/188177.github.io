/*
#include "veriuser.h"

int hello_runoob(){
        io_printf("Hello Runoob! \n");
}
*/

#include "stdio.h"

int hello_runoob(){
        printf("Hello Runoob! \n");
}
