`timescale 1ns/1ps

module test ;

   initial begin
     #10 ;
     $hello_runoob;
   end


   initial begin
      forever begin
         #100;
         if ($time >= 10000)  $finish ;
      end
   end

endmodule // test
